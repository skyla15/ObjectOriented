package practice2;

public class practice2_6 {
	public static void main(String agrs[]) {
		System.out.println("100"+"200");
		// 문자열 100, 문자열 200 으로 100200 으로 붙여져서 나
		System.out.println(100+200);
		// 정수형 100, 정수형 200의 합  => 정수형 300
		System.out.println("100"+200);
		// 문자열 100 + 정수형 200의 문자열로의 캐스팅 
	}
}
